from hashlib import md5
import string
import random

str1 = b"\'or\'"
str2 = b"\'||\'"
str3 = b"'||1#'" 
str4 = b"'or1#'"

i = 0

while True:
    i += 1

    if i % 100000 == 0:
        print(f"Iteration: {i}")

    has = md5()
    rand = ''.join(random.choices(string.digits, k=32))
    has.update(rand.encode('utf-8'))
    raw_hash = has.digest()

    idx = raw_hash.find(str4)
    if idx < 0:
        idx = raw_hash.find(str3)
    
    if idx > 0:
        print("Input: " + rand)
        print("Output: " + has.hexdigest())
        break
    
    idx = raw_hash.find(str1)
    if idx < 0:
        idx = raw_hash.find(str2)
    
    if idx > 0:
        if raw_hash.find(str1) == idx:
            offset = len(str1)
        else:
            offset = len(str2)
        if len(raw_hash) > idx + offset:
            if chr(raw_hash[idx + offset]).isdigit():
                print("Input: " + rand)
                print("Output: " + has.hexdigest())
                break
